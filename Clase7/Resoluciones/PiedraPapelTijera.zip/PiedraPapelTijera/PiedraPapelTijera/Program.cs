﻿using System;

namespace PiedraPapelTijera
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*

             Piedra_Papel_Tijera


             Desarrollar una aplicación de consola que me permita simular una partida de Piedra , Papel o tijera


             Reglas de Negocio

             -La partida se desarrolla entre el Usuario vs La Aplicación
             -El usuario hace una selección y se informa cual es el resultado
             -La aplicación debe permitir jugar mas de una partida
             -Al no querer continuar se tiene que mostrar las estadisticas


             */


            // Algunas configuraciones de la consola 

            // Declaro Variables

            string barra = "";

            const int piedra = 1;
            const int papel = 2;
            const int tijera = 3;


            int eleccionUsuario = 0;
            int eleccionPC = 0;
            int opcionUsuario = 0;


            bool seguirJugando = false;
            bool seleccionInconrrecta = false;
            int contadorUsuario = 0;
            int contadorPC = 0;

            Random rnd = new Random();



            Console.Title = "Piedra papel o tijera";


            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;

            Console.WindowWidth = 40;// Ancho
            Console.WindowHeight = 30; // Altura
            Console.Clear();




            for (int i = 0; i < 40; i++)
            {

                Console.SetCursorPosition(i, 0);

                Console.Write("*");

            }

            Console.WriteLine();


            Console.SetCursorPosition(0, 1);
            Console.WriteLine("|                                      |");
            Console.SetCursorPosition(0, 2);
            Console.WriteLine("|  Bienvenido a Piedra ,Papel o Tijera |");
            Console.SetCursorPosition(0, 3);
            Console.WriteLine("|                                      |");
            for (int i = 0; i < 40; i++)
            {

                Console.SetCursorPosition(i, 4);

                Console.Write("*");

            }


            Console.ReadKey();
            Console.Beep();
            Console.Clear();


            for (int i = 0; i < 10; i++)
            {
                barra += "=";

                Console.Write("Cargando: " + barra);
                System.Threading.Thread.Sleep(200); // Es para poner a dormir el hilo de ejecución por una cantidad de tiempo.

                Console.Clear();
            }


            do
            {



                do
                {

                    Console.WriteLine("Seleccione una opción");
                    Console.WriteLine("1.Piedra");
                    Console.WriteLine("2.Papel");
                    Console.WriteLine("3.Tijera");
                    Console.Write("Opción Elegida:");
                    eleccionUsuario = Convert.ToInt32(Console.ReadLine());

                    if (eleccionUsuario == 1 | eleccionUsuario == 2 | eleccionUsuario == 3)
                    {
                        seleccionInconrrecta = false;
                    }
                    else
                    {
                        seleccionInconrrecta = true;
                        Console.WriteLine("Opción invalida");
                        Console.ReadKey();
                        Console.Clear();
                    }

                } while (seleccionInconrrecta);


                switch (eleccionUsuario)
                {
                    case 1:
                        Console.WriteLine("Elegiste Piedra");

                        break;
                    case 2:
                        Console.WriteLine("Elegiste Papel");
                        break;
                    case 3:
                        Console.WriteLine("Elegiste Tijera");
                        break;
                }

                eleccionPC = rnd.Next(1, 4);


                if (eleccionPC == eleccionUsuario)
                {

                    Console.WriteLine("Empataron!");


                }
                else
                {

                    switch (eleccionUsuario)
                    {

                        case 1:

                            if (eleccionPC == papel)
                            {
                                Console.WriteLine("La Pc saco Papel,perdiste");
                                contadorPC++;

                            }
                            else
                            {

                                Console.WriteLine("La Pc saco Tijera,Ganaste!!!");
                                contadorUsuario++;// contadorUsuario = contadorUsuario + 1;
                            }







                            break;
                        case 2:


                            if (eleccionPC == tijera)
                            {
                                Console.WriteLine("La Pc saco Tijera,perdiste");
                                contadorPC++;
                            }
                            else
                            {

                                Console.WriteLine("La Pc saco Piedra,Ganaste!!!");

                                contadorUsuario++;
                            }




                            break;
                        case 3:


                            if (eleccionPC == piedra)
                            {
                                Console.WriteLine("La Pc saco Piedra,perdiste");
                                contadorPC++;
                            }
                            else
                            {

                                Console.WriteLine("La Pc saco Papel,Ganaste!!!");
                                contadorUsuario++;
                            }



                            break;
                    }


                }



                Console.WriteLine("Desea Seguir Jugando?");
                Console.WriteLine("1.Si");
                Console.WriteLine("2.No");
                Console.Write("Opción Elegida:");
                opcionUsuario = Convert.ToInt32(Console.ReadLine());

                if (opcionUsuario==1)
                {
                    seguirJugando = true;
                    Console.Beep();
                    Console.Clear();

                }
                else
                {
                    seguirJugando = false;
                    Console.Beep();
                    Console.Clear();


                }





            } while (seguirJugando);




            Console.WriteLine("Puntuación Final");
            Console.WriteLine($"PC:{contadorPC}");
            Console.WriteLine($"Usuario:{contadorUsuario}");





            Console.ReadKey();
        }
    }
}
