﻿using System;

namespace Eje1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Declarar las variables 


            double seguroA = 1000;
            double seguroB = 600;
            double seguroC = 200;
            int edad= 0;

            double total = 0;

            int opcionElegida = 0;

            bool menor22 = false;
            bool mayor22menor30 = false;


            Console.WriteLine("Bienvenido , calcule su seguro ");

            Console.WriteLine("Elija el seguro");
            Console.WriteLine("1.Seguro A : $1000");
            Console.WriteLine("2.Seguro B : $600");
            Console.WriteLine("3.Seguro C : $200");
            Console.Write("Opción elegida :");
            opcionElegida = Convert.ToInt32(Console.ReadLine());

            Console.Clear();
            Console.Beep();

            Console.Write("Por favor ingrese su edad: ");
            edad = Convert.ToInt32(Console.ReadLine());


            if (edad < 22)
            {
                menor22 = true;
            }
            else
            {
                menor22 = false;
            }

            if (edad >= 22 & edad < 30)
            {
                mayor22menor30 = true;
            }
            else
            {
                mayor22menor30 = false;
            }


            switch (opcionElegida)
            {

                case 1:

                    total = seguroA;
              
                    break;

                case 2:
                    total = seguroB;
                    break;

                case 3:

                    total = seguroC;

                    break;
            }




            if (menor22)
            {
                Console.WriteLine("Dado su edad tendra un valor agregado del 35%");
                total *= 1.35; // total = total * 1.35;

            }

            if (mayor22menor30)
            {
                Console.WriteLine("Dado su edad tendra un valor agregado del 20%");
                total *= 1.2; // total = total * 1.2;

            }



            Console.WriteLine($"Cuota resultante $:{total}");



            Console.ReadKey();
        }
    }
}
